﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trab_Final_POO
{
    class Agendamento
    {
        public string IdConsultaAgendamento { get; set; }
        public string IdPacienteAgendamento { get; set; }
        public string IdMedicoAgendamento { get; set; }
        public string DataAgendamento { get; set; }
        public string HoraAgendamento { get; set; }
    }
}
