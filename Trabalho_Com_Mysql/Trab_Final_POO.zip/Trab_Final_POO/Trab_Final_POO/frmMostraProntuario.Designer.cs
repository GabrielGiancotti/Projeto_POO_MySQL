﻿namespace Trab_Final_POO
{
    partial class frmMostraProntuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtIdMedicoProntuario = new System.Windows.Forms.TextBox();
            this.lblIdMedicoProntuario = new System.Windows.Forms.Label();
            this.txtIdPacienteProntuario = new System.Windows.Forms.TextBox();
            this.lblIdPacienteProntuario = new System.Windows.Forms.Label();
            this.txtObservacaoProntuario = new System.Windows.Forms.TextBox();
            this.lblObservacaoProntuario = new System.Windows.Forms.Label();
            this.cbxAlcoolotraProntuario = new System.Windows.Forms.ComboBox();
            this.lblAlcoolatraProntuario = new System.Windows.Forms.Label();
            this.cbxFumanteProntuario = new System.Windows.Forms.ComboBox();
            this.lblFumanteProntuario = new System.Windows.Forms.Label();
            this.cbxAlergiaProntuario = new System.Windows.Forms.ComboBox();
            this.lblAlergiaProntuario = new System.Windows.Forms.Label();
            this.cbxCardiacoProntuario = new System.Windows.Forms.ComboBox();
            this.lblCardiacoProntuario = new System.Windows.Forms.Label();
            this.cbxHipertensaoProntuario = new System.Windows.Forms.ComboBox();
            this.lblHipertensaoProntuario = new System.Windows.Forms.Label();
            this.cbxDiabeteProntuario = new System.Windows.Forms.ComboBox();
            this.lblDiabeteProntuario = new System.Windows.Forms.Label();
            this.txtMedicacaoProntuario = new System.Windows.Forms.TextBox();
            this.lblMedicacaoProntuario = new System.Windows.Forms.Label();
            this.txtPrioridadeProntuario = new System.Windows.Forms.TextBox();
            this.lblPrioridadeProntuario = new System.Windows.Forms.Label();
            this.txtIndicacaoProntuario = new System.Windows.Forms.TextBox();
            this.lblIndicacaoProntuario = new System.Windows.Forms.Label();
            this.lblDataProntuario = new System.Windows.Forms.Label();
            this.dtpDataProntuario = new System.Windows.Forms.DateTimePicker();
            this.txtNumeroGuia = new System.Windows.Forms.TextBox();
            this.lblNumeroGuia = new System.Windows.Forms.Label();
            this.dgvMostraProntuario = new System.Windows.Forms.DataGridView();
            this.btnAlterarProntuario = new System.Windows.Forms.Button();
            this.btnExcluirProntuario = new System.Windows.Forms.Button();
            this.btnPesquisarProntuario = new System.Windows.Forms.Button();
            this.btnSalvarProntuario = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMostraProntuario)).BeginInit();
            this.SuspendLayout();
            // 
            // txtIdMedicoProntuario
            // 
            this.txtIdMedicoProntuario.Location = new System.Drawing.Point(648, 61);
            this.txtIdMedicoProntuario.Name = "txtIdMedicoProntuario";
            this.txtIdMedicoProntuario.Size = new System.Drawing.Size(100, 20);
            this.txtIdMedicoProntuario.TabIndex = 48;
            this.txtIdMedicoProntuario.Visible = false;
            this.txtIdMedicoProntuario.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIdMedicoProntuario_KeyPress);
            // 
            // lblIdMedicoProntuario
            // 
            this.lblIdMedicoProntuario.AutoSize = true;
            this.lblIdMedicoProntuario.Location = new System.Drawing.Point(645, 45);
            this.lblIdMedicoProntuario.Name = "lblIdMedicoProntuario";
            this.lblIdMedicoProntuario.Size = new System.Drawing.Size(74, 13);
            this.lblIdMedicoProntuario.TabIndex = 55;
            this.lblIdMedicoProntuario.Text = "ID do Medico:";
            this.lblIdMedicoProntuario.Visible = false;
            // 
            // txtIdPacienteProntuario
            // 
            this.txtIdPacienteProntuario.Location = new System.Drawing.Point(542, 61);
            this.txtIdPacienteProntuario.Name = "txtIdPacienteProntuario";
            this.txtIdPacienteProntuario.Size = new System.Drawing.Size(100, 20);
            this.txtIdPacienteProntuario.TabIndex = 47;
            this.txtIdPacienteProntuario.Visible = false;
            this.txtIdPacienteProntuario.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIdPacienteProntuario_KeyPress);
            // 
            // lblIdPacienteProntuario
            // 
            this.lblIdPacienteProntuario.AutoSize = true;
            this.lblIdPacienteProntuario.Location = new System.Drawing.Point(539, 45);
            this.lblIdPacienteProntuario.Name = "lblIdPacienteProntuario";
            this.lblIdPacienteProntuario.Size = new System.Drawing.Size(81, 13);
            this.lblIdPacienteProntuario.TabIndex = 54;
            this.lblIdPacienteProntuario.Text = "ID do Paciente:";
            this.lblIdPacienteProntuario.Visible = false;
            // 
            // txtObservacaoProntuario
            // 
            this.txtObservacaoProntuario.Location = new System.Drawing.Point(436, 61);
            this.txtObservacaoProntuario.Name = "txtObservacaoProntuario";
            this.txtObservacaoProntuario.Size = new System.Drawing.Size(100, 20);
            this.txtObservacaoProntuario.TabIndex = 45;
            this.txtObservacaoProntuario.Visible = false;
            // 
            // lblObservacaoProntuario
            // 
            this.lblObservacaoProntuario.AutoSize = true;
            this.lblObservacaoProntuario.Location = new System.Drawing.Point(433, 45);
            this.lblObservacaoProntuario.Name = "lblObservacaoProntuario";
            this.lblObservacaoProntuario.Size = new System.Drawing.Size(68, 13);
            this.lblObservacaoProntuario.TabIndex = 53;
            this.lblObservacaoProntuario.Text = "Observação:";
            this.lblObservacaoProntuario.Visible = false;
            // 
            // cbxAlcoolotraProntuario
            // 
            this.cbxAlcoolotraProntuario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxAlcoolotraProntuario.FormattingEnabled = true;
            this.cbxAlcoolotraProntuario.Items.AddRange(new object[] {
            "Sim",
            "Nao"});
            this.cbxAlcoolotraProntuario.Location = new System.Drawing.Point(330, 60);
            this.cbxAlcoolotraProntuario.Name = "cbxAlcoolotraProntuario";
            this.cbxAlcoolotraProntuario.Size = new System.Drawing.Size(100, 21);
            this.cbxAlcoolotraProntuario.TabIndex = 43;
            this.cbxAlcoolotraProntuario.Visible = false;
            // 
            // lblAlcoolatraProntuario
            // 
            this.lblAlcoolatraProntuario.AutoSize = true;
            this.lblAlcoolatraProntuario.Location = new System.Drawing.Point(330, 44);
            this.lblAlcoolatraProntuario.Name = "lblAlcoolatraProntuario";
            this.lblAlcoolatraProntuario.Size = new System.Drawing.Size(60, 13);
            this.lblAlcoolatraProntuario.TabIndex = 52;
            this.lblAlcoolatraProntuario.Text = "Alcoolotra: ";
            this.lblAlcoolatraProntuario.Visible = false;
            // 
            // cbxFumanteProntuario
            // 
            this.cbxFumanteProntuario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxFumanteProntuario.FormattingEnabled = true;
            this.cbxFumanteProntuario.Items.AddRange(new object[] {
            "Sim",
            "Nao"});
            this.cbxFumanteProntuario.Location = new System.Drawing.Point(224, 60);
            this.cbxFumanteProntuario.Name = "cbxFumanteProntuario";
            this.cbxFumanteProntuario.Size = new System.Drawing.Size(100, 21);
            this.cbxFumanteProntuario.TabIndex = 42;
            this.cbxFumanteProntuario.Visible = false;
            // 
            // lblFumanteProntuario
            // 
            this.lblFumanteProntuario.AutoSize = true;
            this.lblFumanteProntuario.Location = new System.Drawing.Point(224, 44);
            this.lblFumanteProntuario.Name = "lblFumanteProntuario";
            this.lblFumanteProntuario.Size = new System.Drawing.Size(54, 13);
            this.lblFumanteProntuario.TabIndex = 51;
            this.lblFumanteProntuario.Text = "Fumante: ";
            this.lblFumanteProntuario.Visible = false;
            // 
            // cbxAlergiaProntuario
            // 
            this.cbxAlergiaProntuario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxAlergiaProntuario.FormattingEnabled = true;
            this.cbxAlergiaProntuario.Items.AddRange(new object[] {
            "Sim",
            "Nao"});
            this.cbxAlergiaProntuario.Location = new System.Drawing.Point(118, 60);
            this.cbxAlergiaProntuario.Name = "cbxAlergiaProntuario";
            this.cbxAlergiaProntuario.Size = new System.Drawing.Size(100, 21);
            this.cbxAlergiaProntuario.TabIndex = 40;
            this.cbxAlergiaProntuario.Visible = false;
            // 
            // lblAlergiaProntuario
            // 
            this.lblAlergiaProntuario.AutoSize = true;
            this.lblAlergiaProntuario.Location = new System.Drawing.Point(118, 44);
            this.lblAlergiaProntuario.Name = "lblAlergiaProntuario";
            this.lblAlergiaProntuario.Size = new System.Drawing.Size(79, 13);
            this.lblAlergiaProntuario.TabIndex = 50;
            this.lblAlergiaProntuario.Text = "Possui Alergia: ";
            this.lblAlergiaProntuario.Visible = false;
            // 
            // cbxCardiacoProntuario
            // 
            this.cbxCardiacoProntuario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxCardiacoProntuario.FormattingEnabled = true;
            this.cbxCardiacoProntuario.Items.AddRange(new object[] {
            "Sim",
            "Nao"});
            this.cbxCardiacoProntuario.Location = new System.Drawing.Point(648, 24);
            this.cbxCardiacoProntuario.Name = "cbxCardiacoProntuario";
            this.cbxCardiacoProntuario.Size = new System.Drawing.Size(100, 21);
            this.cbxCardiacoProntuario.TabIndex = 37;
            this.cbxCardiacoProntuario.Visible = false;
            // 
            // lblCardiacoProntuario
            // 
            this.lblCardiacoProntuario.AutoSize = true;
            this.lblCardiacoProntuario.Location = new System.Drawing.Point(645, 4);
            this.lblCardiacoProntuario.Name = "lblCardiacoProntuario";
            this.lblCardiacoProntuario.Size = new System.Drawing.Size(149, 13);
            this.lblCardiacoProntuario.TabIndex = 49;
            this.lblCardiacoProntuario.Text = "Teve algum ataque cardiaco: ";
            this.lblCardiacoProntuario.Visible = false;
            // 
            // cbxHipertensaoProntuario
            // 
            this.cbxHipertensaoProntuario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxHipertensaoProntuario.FormattingEnabled = true;
            this.cbxHipertensaoProntuario.Items.AddRange(new object[] {
            "Sim",
            "Nao"});
            this.cbxHipertensaoProntuario.Location = new System.Drawing.Point(12, 60);
            this.cbxHipertensaoProntuario.Name = "cbxHipertensaoProntuario";
            this.cbxHipertensaoProntuario.Size = new System.Drawing.Size(100, 21);
            this.cbxHipertensaoProntuario.TabIndex = 39;
            this.cbxHipertensaoProntuario.Visible = false;
            // 
            // lblHipertensaoProntuario
            // 
            this.lblHipertensaoProntuario.AutoSize = true;
            this.lblHipertensaoProntuario.Location = new System.Drawing.Point(12, 44);
            this.lblHipertensaoProntuario.Name = "lblHipertensaoProntuario";
            this.lblHipertensaoProntuario.Size = new System.Drawing.Size(104, 13);
            this.lblHipertensaoProntuario.TabIndex = 46;
            this.lblHipertensaoProntuario.Text = "Possui Hipertensão: ";
            this.lblHipertensaoProntuario.Visible = false;
            // 
            // cbxDiabeteProntuario
            // 
            this.cbxDiabeteProntuario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxDiabeteProntuario.FormattingEnabled = true;
            this.cbxDiabeteProntuario.Items.AddRange(new object[] {
            "Sim",
            "Nao"});
            this.cbxDiabeteProntuario.Location = new System.Drawing.Point(542, 24);
            this.cbxDiabeteProntuario.Name = "cbxDiabeteProntuario";
            this.cbxDiabeteProntuario.Size = new System.Drawing.Size(100, 21);
            this.cbxDiabeteProntuario.TabIndex = 36;
            this.cbxDiabeteProntuario.Visible = false;
            // 
            // lblDiabeteProntuario
            // 
            this.lblDiabeteProntuario.AutoSize = true;
            this.lblDiabeteProntuario.Location = new System.Drawing.Point(542, 8);
            this.lblDiabeteProntuario.Name = "lblDiabeteProntuario";
            this.lblDiabeteProntuario.Size = new System.Drawing.Size(89, 13);
            this.lblDiabeteProntuario.TabIndex = 44;
            this.lblDiabeteProntuario.Text = "Possui Diabetes: ";
            this.lblDiabeteProntuario.Visible = false;
            // 
            // txtMedicacaoProntuario
            // 
            this.txtMedicacaoProntuario.Location = new System.Drawing.Point(436, 24);
            this.txtMedicacaoProntuario.Name = "txtMedicacaoProntuario";
            this.txtMedicacaoProntuario.Size = new System.Drawing.Size(100, 20);
            this.txtMedicacaoProntuario.TabIndex = 35;
            this.txtMedicacaoProntuario.Visible = false;
            // 
            // lblMedicacaoProntuario
            // 
            this.lblMedicacaoProntuario.AutoSize = true;
            this.lblMedicacaoProntuario.Location = new System.Drawing.Point(433, 8);
            this.lblMedicacaoProntuario.Name = "lblMedicacaoProntuario";
            this.lblMedicacaoProntuario.Size = new System.Drawing.Size(63, 13);
            this.lblMedicacaoProntuario.TabIndex = 41;
            this.lblMedicacaoProntuario.Text = "Medicacao:";
            this.lblMedicacaoProntuario.Visible = false;
            // 
            // txtPrioridadeProntuario
            // 
            this.txtPrioridadeProntuario.Location = new System.Drawing.Point(330, 24);
            this.txtPrioridadeProntuario.Name = "txtPrioridadeProntuario";
            this.txtPrioridadeProntuario.Size = new System.Drawing.Size(100, 20);
            this.txtPrioridadeProntuario.TabIndex = 33;
            this.txtPrioridadeProntuario.Visible = false;
            // 
            // lblPrioridadeProntuario
            // 
            this.lblPrioridadeProntuario.AutoSize = true;
            this.lblPrioridadeProntuario.Location = new System.Drawing.Point(327, 8);
            this.lblPrioridadeProntuario.Name = "lblPrioridadeProntuario";
            this.lblPrioridadeProntuario.Size = new System.Drawing.Size(57, 13);
            this.lblPrioridadeProntuario.TabIndex = 38;
            this.lblPrioridadeProntuario.Text = "Prioridade:";
            this.lblPrioridadeProntuario.Visible = false;
            // 
            // txtIndicacaoProntuario
            // 
            this.txtIndicacaoProntuario.Location = new System.Drawing.Point(224, 24);
            this.txtIndicacaoProntuario.Name = "txtIndicacaoProntuario";
            this.txtIndicacaoProntuario.Size = new System.Drawing.Size(100, 20);
            this.txtIndicacaoProntuario.TabIndex = 31;
            this.txtIndicacaoProntuario.Visible = false;
            // 
            // lblIndicacaoProntuario
            // 
            this.lblIndicacaoProntuario.AutoSize = true;
            this.lblIndicacaoProntuario.Location = new System.Drawing.Point(221, 8);
            this.lblIndicacaoProntuario.Name = "lblIndicacaoProntuario";
            this.lblIndicacaoProntuario.Size = new System.Drawing.Size(91, 13);
            this.lblIndicacaoProntuario.TabIndex = 34;
            this.lblIndicacaoProntuario.Text = "Indicacao Clinica:";
            this.lblIndicacaoProntuario.Visible = false;
            // 
            // lblDataProntuario
            // 
            this.lblDataProntuario.AutoSize = true;
            this.lblDataProntuario.Location = new System.Drawing.Point(118, 8);
            this.lblDataProntuario.Name = "lblDataProntuario";
            this.lblDataProntuario.Size = new System.Drawing.Size(33, 13);
            this.lblDataProntuario.TabIndex = 32;
            this.lblDataProntuario.Text = "Data:";
            this.lblDataProntuario.Visible = false;
            // 
            // dtpDataProntuario
            // 
            this.dtpDataProntuario.Location = new System.Drawing.Point(118, 21);
            this.dtpDataProntuario.Name = "dtpDataProntuario";
            this.dtpDataProntuario.Size = new System.Drawing.Size(100, 20);
            this.dtpDataProntuario.TabIndex = 30;
            this.dtpDataProntuario.Visible = false;
            // 
            // txtNumeroGuia
            // 
            this.txtNumeroGuia.Location = new System.Drawing.Point(12, 21);
            this.txtNumeroGuia.Name = "txtNumeroGuia";
            this.txtNumeroGuia.Size = new System.Drawing.Size(100, 20);
            this.txtNumeroGuia.TabIndex = 29;
            this.txtNumeroGuia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeroGuia_KeyPress);
            // 
            // lblNumeroGuia
            // 
            this.lblNumeroGuia.AutoSize = true;
            this.lblNumeroGuia.Location = new System.Drawing.Point(9, 5);
            this.lblNumeroGuia.Name = "lblNumeroGuia";
            this.lblNumeroGuia.Size = new System.Drawing.Size(87, 13);
            this.lblNumeroGuia.TabIndex = 28;
            this.lblNumeroGuia.Text = "Numero da Guia:";
            // 
            // dgvMostraProntuario
            // 
            this.dgvMostraProntuario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMostraProntuario.Location = new System.Drawing.Point(12, 87);
            this.dgvMostraProntuario.Name = "dgvMostraProntuario";
            this.dgvMostraProntuario.Size = new System.Drawing.Size(776, 303);
            this.dgvMostraProntuario.TabIndex = 56;
            // 
            // btnAlterarProntuario
            // 
            this.btnAlterarProntuario.Location = new System.Drawing.Point(203, 396);
            this.btnAlterarProntuario.Name = "btnAlterarProntuario";
            this.btnAlterarProntuario.Size = new System.Drawing.Size(182, 23);
            this.btnAlterarProntuario.TabIndex = 58;
            this.btnAlterarProntuario.Text = "Alterar";
            this.btnAlterarProntuario.UseVisualStyleBackColor = true;
            this.btnAlterarProntuario.Click += new System.EventHandler(this.btnAlterarProntuario_Click);
            // 
            // btnExcluirProntuario
            // 
            this.btnExcluirProntuario.Location = new System.Drawing.Point(391, 396);
            this.btnExcluirProntuario.Name = "btnExcluirProntuario";
            this.btnExcluirProntuario.Size = new System.Drawing.Size(182, 23);
            this.btnExcluirProntuario.TabIndex = 59;
            this.btnExcluirProntuario.Text = "Excluir";
            this.btnExcluirProntuario.UseVisualStyleBackColor = true;
            this.btnExcluirProntuario.Click += new System.EventHandler(this.btnExcluirProntuario_Click);
            // 
            // btnPesquisarProntuario
            // 
            this.btnPesquisarProntuario.Location = new System.Drawing.Point(12, 396);
            this.btnPesquisarProntuario.Name = "btnPesquisarProntuario";
            this.btnPesquisarProntuario.Size = new System.Drawing.Size(185, 23);
            this.btnPesquisarProntuario.TabIndex = 57;
            this.btnPesquisarProntuario.Text = "Pesquisar";
            this.btnPesquisarProntuario.UseVisualStyleBackColor = true;
            this.btnPesquisarProntuario.Click += new System.EventHandler(this.btnPesquisarProntuario_Click);
            // 
            // btnSalvarProntuario
            // 
            this.btnSalvarProntuario.Location = new System.Drawing.Point(579, 396);
            this.btnSalvarProntuario.Name = "btnSalvarProntuario";
            this.btnSalvarProntuario.Size = new System.Drawing.Size(182, 23);
            this.btnSalvarProntuario.TabIndex = 60;
            this.btnSalvarProntuario.Text = "Salvar";
            this.btnSalvarProntuario.UseVisualStyleBackColor = true;
            this.btnSalvarProntuario.Visible = false;
            this.btnSalvarProntuario.Click += new System.EventHandler(this.btnSalvarProntuario_Click);
            // 
            // frmMostraProntuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.btnSalvarProntuario);
            this.Controls.Add(this.btnAlterarProntuario);
            this.Controls.Add(this.btnExcluirProntuario);
            this.Controls.Add(this.btnPesquisarProntuario);
            this.Controls.Add(this.dgvMostraProntuario);
            this.Controls.Add(this.txtIdMedicoProntuario);
            this.Controls.Add(this.lblIdMedicoProntuario);
            this.Controls.Add(this.txtIdPacienteProntuario);
            this.Controls.Add(this.lblIdPacienteProntuario);
            this.Controls.Add(this.txtObservacaoProntuario);
            this.Controls.Add(this.lblObservacaoProntuario);
            this.Controls.Add(this.cbxAlcoolotraProntuario);
            this.Controls.Add(this.lblAlcoolatraProntuario);
            this.Controls.Add(this.cbxFumanteProntuario);
            this.Controls.Add(this.lblFumanteProntuario);
            this.Controls.Add(this.cbxAlergiaProntuario);
            this.Controls.Add(this.lblAlergiaProntuario);
            this.Controls.Add(this.cbxCardiacoProntuario);
            this.Controls.Add(this.lblCardiacoProntuario);
            this.Controls.Add(this.cbxHipertensaoProntuario);
            this.Controls.Add(this.lblHipertensaoProntuario);
            this.Controls.Add(this.cbxDiabeteProntuario);
            this.Controls.Add(this.lblDiabeteProntuario);
            this.Controls.Add(this.txtMedicacaoProntuario);
            this.Controls.Add(this.lblMedicacaoProntuario);
            this.Controls.Add(this.txtPrioridadeProntuario);
            this.Controls.Add(this.lblPrioridadeProntuario);
            this.Controls.Add(this.txtIndicacaoProntuario);
            this.Controls.Add(this.lblIndicacaoProntuario);
            this.Controls.Add(this.lblDataProntuario);
            this.Controls.Add(this.dtpDataProntuario);
            this.Controls.Add(this.txtNumeroGuia);
            this.Controls.Add(this.lblNumeroGuia);
            this.Name = "frmMostraProntuario";
            this.Text = "frmMostraProntuario";
            this.Load += new System.EventHandler(this.frmMostraProntuario_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMostraProntuario)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtIdMedicoProntuario;
        private System.Windows.Forms.Label lblIdMedicoProntuario;
        private System.Windows.Forms.TextBox txtIdPacienteProntuario;
        private System.Windows.Forms.Label lblIdPacienteProntuario;
        private System.Windows.Forms.TextBox txtObservacaoProntuario;
        private System.Windows.Forms.Label lblObservacaoProntuario;
        private System.Windows.Forms.ComboBox cbxAlcoolotraProntuario;
        private System.Windows.Forms.Label lblAlcoolatraProntuario;
        private System.Windows.Forms.ComboBox cbxFumanteProntuario;
        private System.Windows.Forms.Label lblFumanteProntuario;
        private System.Windows.Forms.ComboBox cbxAlergiaProntuario;
        private System.Windows.Forms.Label lblAlergiaProntuario;
        private System.Windows.Forms.ComboBox cbxCardiacoProntuario;
        private System.Windows.Forms.Label lblCardiacoProntuario;
        private System.Windows.Forms.ComboBox cbxHipertensaoProntuario;
        private System.Windows.Forms.Label lblHipertensaoProntuario;
        private System.Windows.Forms.ComboBox cbxDiabeteProntuario;
        private System.Windows.Forms.Label lblDiabeteProntuario;
        private System.Windows.Forms.TextBox txtMedicacaoProntuario;
        private System.Windows.Forms.Label lblMedicacaoProntuario;
        private System.Windows.Forms.TextBox txtPrioridadeProntuario;
        private System.Windows.Forms.Label lblPrioridadeProntuario;
        private System.Windows.Forms.TextBox txtIndicacaoProntuario;
        private System.Windows.Forms.Label lblIndicacaoProntuario;
        private System.Windows.Forms.Label lblDataProntuario;
        private System.Windows.Forms.DateTimePicker dtpDataProntuario;
        private System.Windows.Forms.TextBox txtNumeroGuia;
        private System.Windows.Forms.Label lblNumeroGuia;
        private System.Windows.Forms.DataGridView dgvMostraProntuario;
        private System.Windows.Forms.Button btnAlterarProntuario;
        private System.Windows.Forms.Button btnExcluirProntuario;
        private System.Windows.Forms.Button btnPesquisarProntuario;
        private System.Windows.Forms.Button btnSalvarProntuario;
    }
}