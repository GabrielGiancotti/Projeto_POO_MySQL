﻿namespace Trab_Final_POO
{
    partial class frmCadProntuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCadastrarProntuario = new System.Windows.Forms.Button();
            this.dtpDataProntuario = new System.Windows.Forms.DateTimePicker();
            this.lblDataProntuario = new System.Windows.Forms.Label();
            this.txtIndicacaoProntuario = new System.Windows.Forms.TextBox();
            this.lblIndicacaoProntuario = new System.Windows.Forms.Label();
            this.txtPrioridadeProntuario = new System.Windows.Forms.TextBox();
            this.lblPrioridadeProntuario = new System.Windows.Forms.Label();
            this.txtMedicacaoProntuario = new System.Windows.Forms.TextBox();
            this.lblMedicacaoProntuario = new System.Windows.Forms.Label();
            this.cbxDiabeteProntuario = new System.Windows.Forms.ComboBox();
            this.lblDiabeteProntuario = new System.Windows.Forms.Label();
            this.cbxHipertensaoProntuario = new System.Windows.Forms.ComboBox();
            this.lblHipertensaoProntuario = new System.Windows.Forms.Label();
            this.cbxCardiacoProntuario = new System.Windows.Forms.ComboBox();
            this.lblCardiacoProntuario = new System.Windows.Forms.Label();
            this.cbxAlergiaProntuario = new System.Windows.Forms.ComboBox();
            this.lblAlergiaProntuario = new System.Windows.Forms.Label();
            this.cbxFumanteProntuario = new System.Windows.Forms.ComboBox();
            this.lblFumanteProntuario = new System.Windows.Forms.Label();
            this.cbxAlcoolotraProntuario = new System.Windows.Forms.ComboBox();
            this.lblAlcoolatraProntuario = new System.Windows.Forms.Label();
            this.txtIdMedicoProntuario = new System.Windows.Forms.TextBox();
            this.lblIdMedicoProntuario = new System.Windows.Forms.Label();
            this.txtIdPacienteProntuario = new System.Windows.Forms.TextBox();
            this.lblIdPacienteProntuario = new System.Windows.Forms.Label();
            this.txtObservacaoProntuario = new System.Windows.Forms.TextBox();
            this.lblObservacaoProntuario = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCadastrarProntuario
            // 
            this.btnCadastrarProntuario.Location = new System.Drawing.Point(18, 383);
            this.btnCadastrarProntuario.Name = "btnCadastrarProntuario";
            this.btnCadastrarProntuario.Size = new System.Drawing.Size(776, 20);
            this.btnCadastrarProntuario.TabIndex = 15;
            this.btnCadastrarProntuario.Text = "Cadastrar";
            this.btnCadastrarProntuario.UseVisualStyleBackColor = true;
            this.btnCadastrarProntuario.Click += new System.EventHandler(this.btnCadastrarProntuario_Click);
            // 
            // dtpDataProntuario
            // 
            this.dtpDataProntuario.Location = new System.Drawing.Point(15, 26);
            this.dtpDataProntuario.Name = "dtpDataProntuario";
            this.dtpDataProntuario.Size = new System.Drawing.Size(100, 20);
            this.dtpDataProntuario.TabIndex = 2;
            // 
            // lblDataProntuario
            // 
            this.lblDataProntuario.AutoSize = true;
            this.lblDataProntuario.Location = new System.Drawing.Point(15, 10);
            this.lblDataProntuario.Name = "lblDataProntuario";
            this.lblDataProntuario.Size = new System.Drawing.Size(33, 13);
            this.lblDataProntuario.TabIndex = 4;
            this.lblDataProntuario.Text = "Data:";
            // 
            // txtIndicacaoProntuario
            // 
            this.txtIndicacaoProntuario.Location = new System.Drawing.Point(333, 26);
            this.txtIndicacaoProntuario.Name = "txtIndicacaoProntuario";
            this.txtIndicacaoProntuario.Size = new System.Drawing.Size(100, 20);
            this.txtIndicacaoProntuario.TabIndex = 3;
            // 
            // lblIndicacaoProntuario
            // 
            this.lblIndicacaoProntuario.AutoSize = true;
            this.lblIndicacaoProntuario.Location = new System.Drawing.Point(330, 10);
            this.lblIndicacaoProntuario.Name = "lblIndicacaoProntuario";
            this.lblIndicacaoProntuario.Size = new System.Drawing.Size(91, 13);
            this.lblIndicacaoProntuario.TabIndex = 5;
            this.lblIndicacaoProntuario.Text = "Indicacao Clinica:";
            // 
            // txtPrioridadeProntuario
            // 
            this.txtPrioridadeProntuario.Location = new System.Drawing.Point(651, 26);
            this.txtPrioridadeProntuario.Name = "txtPrioridadeProntuario";
            this.txtPrioridadeProntuario.Size = new System.Drawing.Size(100, 20);
            this.txtPrioridadeProntuario.TabIndex = 4;
            // 
            // lblPrioridadeProntuario
            // 
            this.lblPrioridadeProntuario.AutoSize = true;
            this.lblPrioridadeProntuario.Location = new System.Drawing.Point(648, 10);
            this.lblPrioridadeProntuario.Name = "lblPrioridadeProntuario";
            this.lblPrioridadeProntuario.Size = new System.Drawing.Size(57, 13);
            this.lblPrioridadeProntuario.TabIndex = 7;
            this.lblPrioridadeProntuario.Text = "Prioridade:";
            // 
            // txtMedicacaoProntuario
            // 
            this.txtMedicacaoProntuario.Location = new System.Drawing.Point(15, 81);
            this.txtMedicacaoProntuario.Name = "txtMedicacaoProntuario";
            this.txtMedicacaoProntuario.Size = new System.Drawing.Size(100, 20);
            this.txtMedicacaoProntuario.TabIndex = 5;
            // 
            // lblMedicacaoProntuario
            // 
            this.lblMedicacaoProntuario.AutoSize = true;
            this.lblMedicacaoProntuario.Location = new System.Drawing.Point(12, 65);
            this.lblMedicacaoProntuario.Name = "lblMedicacaoProntuario";
            this.lblMedicacaoProntuario.Size = new System.Drawing.Size(63, 13);
            this.lblMedicacaoProntuario.TabIndex = 9;
            this.lblMedicacaoProntuario.Text = "Medicacao:";
            // 
            // cbxDiabeteProntuario
            // 
            this.cbxDiabeteProntuario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxDiabeteProntuario.FormattingEnabled = true;
            this.cbxDiabeteProntuario.Items.AddRange(new object[] {
            "Sim",
            "Nao"});
            this.cbxDiabeteProntuario.Location = new System.Drawing.Point(333, 81);
            this.cbxDiabeteProntuario.Name = "cbxDiabeteProntuario";
            this.cbxDiabeteProntuario.Size = new System.Drawing.Size(100, 21);
            this.cbxDiabeteProntuario.TabIndex = 6;
            // 
            // lblDiabeteProntuario
            // 
            this.lblDiabeteProntuario.AutoSize = true;
            this.lblDiabeteProntuario.Location = new System.Drawing.Point(333, 65);
            this.lblDiabeteProntuario.Name = "lblDiabeteProntuario";
            this.lblDiabeteProntuario.Size = new System.Drawing.Size(89, 13);
            this.lblDiabeteProntuario.TabIndex = 11;
            this.lblDiabeteProntuario.Text = "Possui Diabetes: ";
            // 
            // cbxHipertensaoProntuario
            // 
            this.cbxHipertensaoProntuario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxHipertensaoProntuario.FormattingEnabled = true;
            this.cbxHipertensaoProntuario.Items.AddRange(new object[] {
            "Sim",
            "Nao"});
            this.cbxHipertensaoProntuario.Location = new System.Drawing.Point(15, 141);
            this.cbxHipertensaoProntuario.Name = "cbxHipertensaoProntuario";
            this.cbxHipertensaoProntuario.Size = new System.Drawing.Size(100, 21);
            this.cbxHipertensaoProntuario.TabIndex = 8;
            // 
            // lblHipertensaoProntuario
            // 
            this.lblHipertensaoProntuario.AutoSize = true;
            this.lblHipertensaoProntuario.Location = new System.Drawing.Point(15, 125);
            this.lblHipertensaoProntuario.Name = "lblHipertensaoProntuario";
            this.lblHipertensaoProntuario.Size = new System.Drawing.Size(104, 13);
            this.lblHipertensaoProntuario.TabIndex = 13;
            this.lblHipertensaoProntuario.Text = "Possui Hipertensão: ";
            // 
            // cbxCardiacoProntuario
            // 
            this.cbxCardiacoProntuario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxCardiacoProntuario.FormattingEnabled = true;
            this.cbxCardiacoProntuario.Items.AddRange(new object[] {
            "Sim",
            "Nao"});
            this.cbxCardiacoProntuario.Location = new System.Drawing.Point(651, 80);
            this.cbxCardiacoProntuario.Name = "cbxCardiacoProntuario";
            this.cbxCardiacoProntuario.Size = new System.Drawing.Size(100, 21);
            this.cbxCardiacoProntuario.TabIndex = 7;
            // 
            // lblCardiacoProntuario
            // 
            this.lblCardiacoProntuario.AutoSize = true;
            this.lblCardiacoProntuario.Location = new System.Drawing.Point(648, 60);
            this.lblCardiacoProntuario.Name = "lblCardiacoProntuario";
            this.lblCardiacoProntuario.Size = new System.Drawing.Size(149, 13);
            this.lblCardiacoProntuario.TabIndex = 15;
            this.lblCardiacoProntuario.Text = "Teve algum ataque cardiaco: ";
            // 
            // cbxAlergiaProntuario
            // 
            this.cbxAlergiaProntuario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxAlergiaProntuario.FormattingEnabled = true;
            this.cbxAlergiaProntuario.Items.AddRange(new object[] {
            "Sim",
            "Nao"});
            this.cbxAlergiaProntuario.Location = new System.Drawing.Point(333, 141);
            this.cbxAlergiaProntuario.Name = "cbxAlergiaProntuario";
            this.cbxAlergiaProntuario.Size = new System.Drawing.Size(100, 21);
            this.cbxAlergiaProntuario.TabIndex = 9;
            // 
            // lblAlergiaProntuario
            // 
            this.lblAlergiaProntuario.AutoSize = true;
            this.lblAlergiaProntuario.Location = new System.Drawing.Point(333, 125);
            this.lblAlergiaProntuario.Name = "lblAlergiaProntuario";
            this.lblAlergiaProntuario.Size = new System.Drawing.Size(79, 13);
            this.lblAlergiaProntuario.TabIndex = 17;
            this.lblAlergiaProntuario.Text = "Possui Alergia: ";
            // 
            // cbxFumanteProntuario
            // 
            this.cbxFumanteProntuario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxFumanteProntuario.FormattingEnabled = true;
            this.cbxFumanteProntuario.Items.AddRange(new object[] {
            "Sim",
            "Nao"});
            this.cbxFumanteProntuario.Location = new System.Drawing.Point(651, 141);
            this.cbxFumanteProntuario.Name = "cbxFumanteProntuario";
            this.cbxFumanteProntuario.Size = new System.Drawing.Size(100, 21);
            this.cbxFumanteProntuario.TabIndex = 10;
            // 
            // lblFumanteProntuario
            // 
            this.lblFumanteProntuario.AutoSize = true;
            this.lblFumanteProntuario.Location = new System.Drawing.Point(651, 125);
            this.lblFumanteProntuario.Name = "lblFumanteProntuario";
            this.lblFumanteProntuario.Size = new System.Drawing.Size(54, 13);
            this.lblFumanteProntuario.TabIndex = 19;
            this.lblFumanteProntuario.Text = "Fumante: ";
            // 
            // cbxAlcoolotraProntuario
            // 
            this.cbxAlcoolotraProntuario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxAlcoolotraProntuario.FormattingEnabled = true;
            this.cbxAlcoolotraProntuario.Items.AddRange(new object[] {
            "Sim",
            "Nao"});
            this.cbxAlcoolotraProntuario.Location = new System.Drawing.Point(15, 203);
            this.cbxAlcoolotraProntuario.Name = "cbxAlcoolotraProntuario";
            this.cbxAlcoolotraProntuario.Size = new System.Drawing.Size(100, 21);
            this.cbxAlcoolotraProntuario.TabIndex = 11;
            // 
            // lblAlcoolatraProntuario
            // 
            this.lblAlcoolatraProntuario.AutoSize = true;
            this.lblAlcoolatraProntuario.Location = new System.Drawing.Point(15, 187);
            this.lblAlcoolatraProntuario.Name = "lblAlcoolatraProntuario";
            this.lblAlcoolatraProntuario.Size = new System.Drawing.Size(60, 13);
            this.lblAlcoolatraProntuario.TabIndex = 21;
            this.lblAlcoolatraProntuario.Text = "Alcoolotra: ";
            // 
            // txtIdMedicoProntuario
            // 
            this.txtIdMedicoProntuario.Location = new System.Drawing.Point(15, 264);
            this.txtIdMedicoProntuario.Name = "txtIdMedicoProntuario";
            this.txtIdMedicoProntuario.Size = new System.Drawing.Size(100, 20);
            this.txtIdMedicoProntuario.TabIndex = 14;
            this.txtIdMedicoProntuario.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIdMedicoProntuario_KeyPress);
            // 
            // lblIdMedicoProntuario
            // 
            this.lblIdMedicoProntuario.AutoSize = true;
            this.lblIdMedicoProntuario.Location = new System.Drawing.Point(12, 248);
            this.lblIdMedicoProntuario.Name = "lblIdMedicoProntuario";
            this.lblIdMedicoProntuario.Size = new System.Drawing.Size(74, 13);
            this.lblIdMedicoProntuario.TabIndex = 27;
            this.lblIdMedicoProntuario.Text = "ID do Medico:";
            // 
            // txtIdPacienteProntuario
            // 
            this.txtIdPacienteProntuario.Location = new System.Drawing.Point(651, 204);
            this.txtIdPacienteProntuario.Name = "txtIdPacienteProntuario";
            this.txtIdPacienteProntuario.Size = new System.Drawing.Size(100, 20);
            this.txtIdPacienteProntuario.TabIndex = 13;
            this.txtIdPacienteProntuario.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIdPacienteProntuario_KeyPress);
            // 
            // lblIdPacienteProntuario
            // 
            this.lblIdPacienteProntuario.AutoSize = true;
            this.lblIdPacienteProntuario.Location = new System.Drawing.Point(648, 188);
            this.lblIdPacienteProntuario.Name = "lblIdPacienteProntuario";
            this.lblIdPacienteProntuario.Size = new System.Drawing.Size(81, 13);
            this.lblIdPacienteProntuario.TabIndex = 25;
            this.lblIdPacienteProntuario.Text = "ID do Paciente:";
            // 
            // txtObservacaoProntuario
            // 
            this.txtObservacaoProntuario.Location = new System.Drawing.Point(333, 204);
            this.txtObservacaoProntuario.Name = "txtObservacaoProntuario";
            this.txtObservacaoProntuario.Size = new System.Drawing.Size(100, 20);
            this.txtObservacaoProntuario.TabIndex = 12;
            // 
            // lblObservacaoProntuario
            // 
            this.lblObservacaoProntuario.AutoSize = true;
            this.lblObservacaoProntuario.Location = new System.Drawing.Point(330, 188);
            this.lblObservacaoProntuario.Name = "lblObservacaoProntuario";
            this.lblObservacaoProntuario.Size = new System.Drawing.Size(68, 13);
            this.lblObservacaoProntuario.TabIndex = 23;
            this.lblObservacaoProntuario.Text = "Observação:";
            // 
            // frmCadProntuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 415);
            this.ControlBox = false;
            this.Controls.Add(this.txtIdMedicoProntuario);
            this.Controls.Add(this.lblIdMedicoProntuario);
            this.Controls.Add(this.txtIdPacienteProntuario);
            this.Controls.Add(this.lblIdPacienteProntuario);
            this.Controls.Add(this.txtObservacaoProntuario);
            this.Controls.Add(this.lblObservacaoProntuario);
            this.Controls.Add(this.cbxAlcoolotraProntuario);
            this.Controls.Add(this.lblAlcoolatraProntuario);
            this.Controls.Add(this.cbxFumanteProntuario);
            this.Controls.Add(this.lblFumanteProntuario);
            this.Controls.Add(this.cbxAlergiaProntuario);
            this.Controls.Add(this.lblAlergiaProntuario);
            this.Controls.Add(this.cbxCardiacoProntuario);
            this.Controls.Add(this.lblCardiacoProntuario);
            this.Controls.Add(this.cbxHipertensaoProntuario);
            this.Controls.Add(this.lblHipertensaoProntuario);
            this.Controls.Add(this.cbxDiabeteProntuario);
            this.Controls.Add(this.lblDiabeteProntuario);
            this.Controls.Add(this.txtMedicacaoProntuario);
            this.Controls.Add(this.lblMedicacaoProntuario);
            this.Controls.Add(this.txtPrioridadeProntuario);
            this.Controls.Add(this.lblPrioridadeProntuario);
            this.Controls.Add(this.txtIndicacaoProntuario);
            this.Controls.Add(this.lblIndicacaoProntuario);
            this.Controls.Add(this.lblDataProntuario);
            this.Controls.Add(this.dtpDataProntuario);
            this.Controls.Add(this.btnCadastrarProntuario);
            this.Name = "frmCadProntuario";
            this.Text = "Cadastro de Prontuarios";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnCadastrarProntuario;
        private System.Windows.Forms.DateTimePicker dtpDataProntuario;
        private System.Windows.Forms.Label lblDataProntuario;
        private System.Windows.Forms.TextBox txtIndicacaoProntuario;
        private System.Windows.Forms.Label lblIndicacaoProntuario;
        private System.Windows.Forms.TextBox txtPrioridadeProntuario;
        private System.Windows.Forms.Label lblPrioridadeProntuario;
        private System.Windows.Forms.TextBox txtMedicacaoProntuario;
        private System.Windows.Forms.Label lblMedicacaoProntuario;
        private System.Windows.Forms.ComboBox cbxDiabeteProntuario;
        private System.Windows.Forms.Label lblDiabeteProntuario;
        private System.Windows.Forms.ComboBox cbxHipertensaoProntuario;
        private System.Windows.Forms.Label lblHipertensaoProntuario;
        private System.Windows.Forms.ComboBox cbxCardiacoProntuario;
        private System.Windows.Forms.Label lblCardiacoProntuario;
        private System.Windows.Forms.ComboBox cbxAlergiaProntuario;
        private System.Windows.Forms.Label lblAlergiaProntuario;
        private System.Windows.Forms.ComboBox cbxFumanteProntuario;
        private System.Windows.Forms.Label lblFumanteProntuario;
        private System.Windows.Forms.ComboBox cbxAlcoolotraProntuario;
        private System.Windows.Forms.Label lblAlcoolatraProntuario;
        private System.Windows.Forms.TextBox txtIdMedicoProntuario;
        private System.Windows.Forms.Label lblIdMedicoProntuario;
        private System.Windows.Forms.TextBox txtIdPacienteProntuario;
        private System.Windows.Forms.Label lblIdPacienteProntuario;
        private System.Windows.Forms.TextBox txtObservacaoProntuario;
        private System.Windows.Forms.Label lblObservacaoProntuario;
    }
}